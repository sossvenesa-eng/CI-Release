import assert from "node:assert/strict";
import { mkdir, mkdtemp, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

// Run from any directory: node scripts/mcp-examples.mjs [--packaged]
// Uses only repository fixtures and a fresh, retained output/cache directory.
const root = fileURLToPath(new URL("../", import.meta.url));
const options = process.argv.slice(2);
if (options.some(option => option !== "--packaged")) {
  throw new Error("Usage: node scripts/mcp-examples.mjs [--packaged]");
}
const packaged = options.includes("--packaged");
if (packaged && process.platform !== "win32") throw new Error("--packaged requires Windows");
const parent = path.join(root, "outputs/mcp-examples");
await mkdir(parent, { recursive: true });
const output = await mkdtemp(path.join(parent, packaged ? "portable-" : "source-"));
const cache = path.join(output, "cache");
const app = path.join(root, "release-guideline-below-test-list/win-unpacked");
const resources = path.join(app, "resources");
const binary = process.platform === "win32" ? "circuit-inspector-core.exe" : "circuit-inspector-core";
const client = new Client({ name: "circuit-inspector-examples", version: "1.0.0" });
const env = Object.fromEntries(Object.entries(process.env).filter(([, value]) => value !== undefined));
// A globally inherited Electron flag must not affect the source Node process.
delete env.ELECTRON_RUN_AS_NODE;
const transport = new StdioClientTransport({
  command: packaged ? path.join(app, "CircuitInspector.exe") : process.execPath,
  args: [packaged ? path.join(resources, "app.asar/dist/mcp/index.js") : path.join(root, "apps/mcp/dist/index.js")],
  cwd: root,
  env: {
    ...env,
    CIRCUIT_INSPECTOR_CACHE_DIR: cache,
    CIRCUIT_INSPECTOR_CORE: packaged ? path.join(resources, "bin", binary) : path.join(root, "target/release", binary),
    CIRCUIT_INSPECTOR_PDF_ASSET_DIR: packaged ? path.join(resources, "pdfjs") : path.join(root, "node_modules/pdfjs-dist"),
    ...(packaged ? { ELECTRON_RUN_AS_NODE: "1", CIRCUIT_INSPECTOR_OCR_DIR: path.join(resources, "ocr") } : {})
  },
  stderr: "pipe"
});
let stderr = "";
transport.stderr?.on("data", chunk => { stderr += chunk.toString(); });
const calls = [];
let failure = null;
const json = (name, value) => writeFile(path.join(output, name), JSON.stringify(value, null, 2) + "\n");

async function call(name, args = {}, expectedError = false) {
  const request = { name, arguments: args };
  const started = performance.now();
  let response;
  try {
    response = await client.callTool(request);
  } catch (error) {
    calls.push({ request, expected_error: expectedError, transport_error: String(error) });
    throw error;
  }
  calls.push({ request, expected_error: expectedError, duration_ms: Math.round(performance.now() - started), response });
  assert.equal(Boolean(response.isError), expectedError, `${name}: ${JSON.stringify(response)}`);
  console.log(`${expectedError ? "EXPECTED REJECTION" : "OK"}: ${name}`);
  const content = response.structuredContent;
  return content && Object.hasOwn(content, "result") ? content.result : content;
}

try {
  await client.connect(transport);
  await client.ping();
  const tools = (await client.listTools()).tools;
  await json("tools.json", tools);
  console.log(`Connected: ${tools.length} tools; output: ${output}`);
  await call("ping");
  await call("get_mcp_capabilities");
  await call("list_rule_packs");

  const design = await call("import_design", { path: path.join(root, "fixtures/gerber/simple") });
  await call("get_design_summary", { design_id: design.id });
  const found = await call("search_design", { design_id: design.id, query: "TP1" });
  assert.ok(found.results.length > 0);
  await call("list_test_points", { design_id: design.id });
  const measurement = await call("measure_points", { from: { x: 0, y: 0 }, to: { x: 3000000, y: 4000000 } });
  assert.equal(measurement.distance_mm, 5);
  const trace = await call("trace_design_connection", { design_id: design.id, point: { x: 10000000, y: 5000000 } });
  assert.equal(trace.selection.status, "REVIEW");
  await call("read_design_keep_out_regions", { design_id: design.id });
  const csv = await call("export_drawing_test_points", { format: "GERBER", id: design.id, locale: "zh-CN" });
  await call("read_cached_file", { relative_path: path.relative(cache, csv.path).split(path.sep).join("/"), encoding: "utf8" });

  // Synthetic requirements exercise all three verdicts without customer data.
  const requirement = path.join(output, "requirements-match.csv");
  const mismatch = path.join(output, "requirements-mismatch.csv");
  await writeFile(requirement, "TP,side,net\nTP1,TOP,NET_TEST_A\n");
  await writeFile(mismatch, "TP,side,net\nTP1,BOTTOM,WRONG\nTP404,TOP,GND\n");
  for (const [args, verdict] of [
    [{ path: requirement, design_id: design.id, locale: "zh-CN" }, "PASS"],
    [{ path: mismatch, design_id: design.id, locale: "zh-CN" }, "FAIL"],
    [{ path: requirement, locale: "zh-CN" }, "REVIEW"]
  ]) {
    const analysis = await call("analyze_requirements", args);
    assert.equal(analysis.verdict, verdict);
  }

  const rulePath = path.join(root, "docs/rules/fixture-rule.md");
  await call("preview_rule_file", { paths: [rulePath] });
  const ruleAnalysis = await call("analyze_rule_file", { path: rulePath, design_id: design.id });
  await call("export_analysis_report", { analysis_id: ruleAnalysis.id });

  const catalog = await call("import_brd_test_points", { path: path.join(root, "fixtures/brd/layer-viewer.kicad_pcb") });
  await call("query_brd_test_points", { catalog_id: catalog.id });
  const drawing = await call("read_brd_drawing_layers", { catalog_id: catalog.id });
  const componentIndex = drawing.components.findIndex(component => component.refdes === "U1");
  assert.ok(componentIndex >= 0);
  const pins = await call("read_brd_component_pins", { catalog_id: catalog.id, component_index: componentIndex });
  assert.deepEqual(pins.map(pin => [pin.number, pin.net_name]), [["1", "GND"], ["2", "VCC"]]);
  await call("read_brd_net_components", { catalog_id: catalog.id, net_name: "GND" });
  // Same-version comparison is a no-change sanity check, not revision coverage.
  const compared = await call("compare_brd_versions", { before_catalog_id: catalog.id, after_catalog_id: catalog.id, export_report: true, locale: "zh-CN" });
  assert.deepEqual(compared.test_points, []);
  await call("export_drawing_test_points", { format: "BRD", id: catalog.id, locale: "zh-CN" });

  await call("read_design_keep_out_regions", { design_id: "../escape" }, true);
  await call("read_cached_file", { relative_path: "../outside" }, true);
} catch (error) {
  failure = String(error);
  process.exitCode = 1;
  console.error(error);
} finally {
  try { await client.close(); } catch (error) { failure ??= String(error); process.exitCode = 1; }
  try { await transport.close(); } catch (error) { failure ??= String(error); process.exitCode = 1; }
  await json("calls.json", { completed_at: new Date().toISOString(), runtime: packaged ? "portable EXE" : "Node bundle", passed: failure === null, failure, cache, calls });
  await writeFile(path.join(output, "requests.jsonl"), calls.map(({ request }, index) => JSON.stringify({ jsonrpc: "2.0", id: index + 1, method: "tools/call", params: request })).join("\n") + "\n");
  await writeFile(path.join(output, "server-stderr.log"), stderr);
  console.log(`${failure ? "FAILED" : "PASS"}: ${calls.length} calls; saved to ${output}`);
}
