# MCP 指令实例与可执行示例

本页适用于本仓库 CircuitInspector 0.2.22。2026-11-16 实际连接源码 MCP 返回 **92 个工具**；精确参数以当前连接的 `tools/list` 为准。

## 1. 一键运行示例

在仓库根目录的 PowerShell 执行：

```powershell
Set-Location 'D:\00_AI\00_Code\CircuitInspector-main'
# Cargo 已安装但不在 PATH 时，可在当前终端补充：
$env:PATH = "$env:USERPROFILE\.cargo\bin;$env:PATH"
npm run build:core
npm run build:mcp
node scripts/mcp-examples.mjs
```

脚本通过 MCP SDK 创建真实 stdio 会话，自动完成初始化、工具发现和调用，自动传递设计、图纸与分析 ID。只使用仓库夹具及合成需求，每次创建独立输出目录，不依赖现有规则审批。

控制台会打印本次目录 `outputs/mcp-examples/source-<随机后缀>/`，其中保留：

| 文件 | 用途 |
| --- | --- |
| `tools.json` | 当前服务的完整工具清单、输入和输出 schema |
| `calls.json` | 实际请求、实际返回、耗时、预期拒绝和运行结果 |
| `requests.jsonl` | 每行一个 `tools/call` JSON-RPC 请求，ID 已由本次返回值填充 |
| `requirements-match.csv` / `requirements-mismatch.csv` | 演示 PASS / FAIL / REVIEW 的合成输入 |
| `cache/` | 本次导入缓存、分析结果、HTML / CSV 报告 |
| `server-stderr.log` | 服务端诊断日志 |

`requests.jsonl` 是已执行请求的记录；重放需要先由 MCP 客户端初始化会话，并使用对应缓存。重新运行脚本更适合完整复现。输出中最后两个请求故意验证非法 ID 和缓存越界拒绝。

测试现有 Windows 便携 EXE 时，从非受限桌面 PowerShell 运行：

```powershell
node scripts/mcp-examples.mjs --packaged
```

默认应用目录为 `release-guideline-below-test-list/win-unpacked`，需保留全部配套文件。此参数验证现有包，不会重新打包。源码模式要求 Node.js 和已构建核心；EXE 模式使用包内 MCP 和核心，示例驱动本身仍由 Node.js 运行。

## 2. 连接与结果读取

连接到已经配置好的 `circuit-inspector` MCP 后，可直接发送以下自然语言指令：

```text
请实际调用 circuit-inspector 的 ping 和 get_mcp_capabilities，参数均为 {}。
再通过 MCP tools/list 获取工具清单，报告服务版本、工具总数和可用功能。
不要只描述调用方法，请展示真实调用结果。
```

`tools/list` 是 MCP 协议方法，不是一个名为 `tools/list` 的业务工具；`get_mcp_capabilities` 的 `tools` 仅覆盖扩展工具，不能据此计算全部工具数量。

下方 JSON 均为 `tools/call` 的 **params**，也是 SDK `client.callTool()` 的输入，不是 PowerShell 命令。例如完整消息为：

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"ping","arguments":{}}}
```

先检查返回 `isError`。原有工具通常直接返回 `structuredContent`；扩展工具返回 `structuredContent.result`。例如 `import_design` 的 ID 是 `structuredContent.id`，`analyze_rule_file` 的 ID 是 `structuredContent.result.id`。以下 `<design_id>` 等占位符必须替换为本次实际返回值。

## 3. 导入制造数据，查询测试点

```text
请导入 D:/00_AI/00_Code/CircuitInspector-main/fixtures/gerber/simple，
使用返回的设计 ID 获取摘要、搜索 TP1，并列出测试点。
请给出图层、测试点数量和语义覆盖情况；未知项保留原状态。
```

依次调用：

```json
{"name":"import_design","arguments":{"path":"D:/00_AI/00_Code/CircuitInspector-main/fixtures/gerber/simple"}}
{"name":"get_design_summary","arguments":{"design_id":"<design_id>"}}
{"name":"search_design","arguments":{"design_id":"<design_id>","query":"TP1"}}
{"name":"list_test_points","arguments":{"design_id":"<design_id>"}}
```

ODB++ 示例将导入路径替换为 `D:/00_AI/00_Code/CircuitInspector-main/fixtures/odb/simple`。CAD 文件走第 7 节的 `import_brd_test_points`。

这里使用普通搜索。实测 Gerber 示例的 `query: "TP1"` 能命中，额外传入 `find_target: "tp"` 时返回空命中；限定类别搜索并不等同于所有源对象搜索。不要把空命中解释为不存在测试点或检查通过。

## 4. 几何测量、连线与 Keep-Out

```text
请测量 (0,0) 到 (3000000,4000000) 的距离，坐标单位为纳米。
再从已导入示例设计的 (10000000,5000000) 追踪铜连接，并读取 Keep-Out。
展示真实连接状态、未闭合端点和不支持对象数量，不把空结果当成 PASS。
```

```json
{"name":"measure_points","arguments":{"from":{"x":0,"y":0},"to":{"x":3000000,"y":4000000}}}
{"name":"trace_design_connection","arguments":{"design_id":"<design_id>","point":{"x":10000000,"y":5000000}}}
{"name":"read_design_keep_out_regions","arguments":{"design_id":"<design_id>"}}
```

测量应返回 `distance_mm: 5`；该 Gerber 夹具的连线状态为 `REVIEW`。1 mm = 1,000,000 nm。坐标需为安全范围内的整数，图层 ID 使用导入摘要的实际值。

## 5. ERS / TRP 需求核对

```text
请使用本次示例输出目录中的 requirements-match.csv，对已导入设计运行
analyze_requirements，输出中文报告。再运行 requirements-mismatch.csv，
最后不传 design_id 对 match 文件做文档检查。请分别列出 verdict、发现项、
证据位置、HTML 和 CSV 路径，保留 REVIEW 的原因。
```

```json
{"name":"analyze_requirements","arguments":{"path":"<本次输出目录>/requirements-match.csv","design_id":"<design_id>","locale":"zh-CN"}}
{"name":"analyze_requirements","arguments":{"path":"<本次输出目录>/requirements-mismatch.csv","design_id":"<design_id>","locale":"zh-CN"}}
{"name":"analyze_requirements","arguments":{"path":"<本次输出目录>/requirements-match.csv","locale":"zh-CN"}}
```

对本示例依次断言 `PASS`、`FAIL`、`REVIEW`。匹配输入为 `TP1,TOP,NET_TEST_A`；冲突输入包含 `TP1,BOTTOM,WRONG` 和不存在的 `TP404`。这些是合成测试数据，不能替代实际客户资料的验收。

## 6. 按规则文档检查并导出报告

```text
请预览 D:/00_AI/00_Code/CircuitInspector-main/docs/rules/fixture-rule.md，
列出抽取的规则和不确定项，再对已导入设计执行这些规则并导出分析报告。
不要自动审批规则库或把 REVIEW 改成 PASS。
```

```json
{"name":"preview_rule_file","arguments":{"paths":["D:/00_AI/00_Code/CircuitInspector-main/docs/rules/fixture-rule.md"]}}
{"name":"analyze_rule_file","arguments":{"path":"D:/00_AI/00_Code/CircuitInspector-main/docs/rules/fixture-rule.md","design_id":"<design_id>"}}
{"name":"export_analysis_report","arguments":{"analysis_id":"<analyze_rule_file 返回的 result.id>"}}
```

只检查部分规则时，传入从预览中读到的 `selected_rule_ids` 数组；不要手编规则 ID。规则文档分析不会自动批准规则库。人工复核、确认和审批类工具需使用真实授权身份，示例脚本不调用这些接口。

## 7. CAD 测试点、器件引脚与版本比较

```text
请导入 D:/00_AI/00_Code/CircuitInspector-main/fixtures/brd/layer-viewer.kicad_pcb，
读取图层元数据，找到 refdes 为 U1 的器件在 components 数组中的索引，
用该索引读取引脚，并列出 GND 网络关联器件，最后导出测试点 CSV。
```

```json
{"name":"import_brd_test_points","arguments":{"path":"D:/00_AI/00_Code/CircuitInspector-main/fixtures/brd/layer-viewer.kicad_pcb"}}
{"name":"query_brd_test_points","arguments":{"catalog_id":"<catalog_id>"}}
{"name":"read_brd_drawing_layers","arguments":{"catalog_id":"<catalog_id>"}}
{"name":"read_brd_component_pins","arguments":{"catalog_id":"<catalog_id>","component_index":0}}
{"name":"read_brd_net_components","arguments":{"catalog_id":"<catalog_id>","net_name":"GND"}}
{"name":"export_drawing_test_points","arguments":{"format":"BRD","id":"<catalog_id>","locale":"zh-CN"}}
```

`component_index: 0` 仅展示数值格式，执行前必须替换为 U1 在返回数组中的实际索引（从 0 开始）；脚本会自动查找。该夹具 U1 的引脚 1 / 2 分别属于 GND / VCC。

两个版本分别导入后执行：

```json
{"name":"compare_brd_versions","arguments":{"before_catalog_id":"<旧版 catalog_id>","after_catalog_id":"<新版 catalog_id>","export_report":true,"locale":"zh-CN"}}
```

示例脚本使用同一个 catalog ID 比较自身，验证无 TP 变化和报告生成；这不是不同真实版本的差异验收。

## 8. 读取导出文件

```json
{"name":"export_drawing_test_points","arguments":{"format":"GERBER","id":"<design_id>","locale":"zh-CN"}}
{"name":"read_cached_file","arguments":{"relative_path":"<相对于当前服务 cache_directory 的导出路径>","encoding":"utf8"}}
```

`cache_directory` 可从 `get_mcp_capabilities` 返回值读取。文本用 `utf8`，图片或二进制用 `base64`；文件上限 8 MiB。应将导出绝对路径转换成缓存相对路径，不传入外部路径或 `..`。示例脚本会自动转换。

## 9. 复跑全量测试

在仓库根目录执行，可避免 npm workspace 改变相对报告路径的解析位置：

```powershell
npm run typecheck
npm run test:rust
npm run test:ts -- --maxWorkers=2
node apps/mcp/test/inspection-tools.e2e.mjs --all --report outputs/mcp-validation/source-e2e.json
# 以下从非受限 Windows 桌面进程执行：
node apps/mcp/test/inspection-tools.e2e.mjs --all --packaged --report outputs/mcp-validation/portable-e2e.json
```

全量端到端测试使用独立临时缓存，包括合成资料的审批及拒绝分支，结束后清理；与保留报告的示例脚本分开。测试记录见 [2026-11-16 验证记录](mcp-validation-2026-11-16.zh-CN.md)。
